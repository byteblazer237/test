
import React from 'react';
import { AppTab } from '../types';

interface SidebarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: AppTab.CHAT, label: 'Nexus Chat', icon: 'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z' },
    { id: AppTab.SEARCH, label: 'Live Intel', icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z' },
    { id: AppTab.VISION, label: 'Vision Lab', icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { id: AppTab.VOICE, label: 'Voice Link', icon: 'M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z' },
  ];

  return (
    <div className="w-20 md:w-64 h-screen bg-white border-r border-gray-100 flex flex-col items-center py-8">
      <div className="mb-10 px-4 flex items-center gap-3">
        <div className="w-10 h-10 bg-black rounded-xl flex items-center justify-center shadow-lg">
          <div className="w-5 h-5 border-2 border-white rounded-full"></div>
        </div>
        <h1 className="hidden md:block text-xl font-bold tracking-tight">Nexus Studio</h1>
      </div>
      
      <nav className="flex-1 w-full px-2 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all duration-200 ${
              activeTab === item.id 
                ? 'bg-gray-900 text-white shadow-md' 
                : 'text-gray-500 hover:bg-gray-50'
            }`}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
            </svg>
            <span className="hidden md:block font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="px-4 mt-auto">
        <div className="w-full h-1 bg-gray-100 rounded-full mb-6"></div>
        <div className="hidden md:flex items-center gap-3 p-3 rounded-2xl bg-gray-50">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500"></div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold">Pro Plan</span>
            <span className="text-xs text-gray-500">Enterprise Ready</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
