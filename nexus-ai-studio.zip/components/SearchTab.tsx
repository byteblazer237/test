
import React, { useState } from 'react';
import { gemini } from '../services/geminiService';

const SearchTab: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<{ text: string, urls: { uri: string, title: string }[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim() || loading) return;
    setLoading(true);
    try {
      const data = await gemini.searchGrounding(query);
      setResult(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-2 mb-10">
        <h2 className="text-3xl font-bold">Real-time Intelligence</h2>
        <p className="text-gray-500">Search the live web with AI-powered synthesis.</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          placeholder="What's happening in tech today?"
          className="flex-1 bg-white border border-gray-200 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-black/5 apple-shadow"
        />
        <button
          onClick={handleSearch}
          disabled={!query.trim() || loading}
          className="px-8 bg-black text-white rounded-2xl font-semibold hover:bg-gray-800 transition-colors disabled:opacity-50"
        >
          {loading ? 'Searching...' : 'Explore'}
        </button>
      </div>

      {result && (
        <div className="bg-white rounded-3xl p-8 border border-gray-100 apple-shadow space-y-6">
          <div className="prose prose-sm max-w-none text-gray-800 leading-relaxed">
            {result.text}
          </div>
          
          {result.urls.length > 0 && (
            <div className="pt-6 border-t border-gray-50">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Sources</h4>
              <div className="flex flex-wrap gap-3">
                {result.urls.map((u, i) => (
                  <a
                    key={i}
                    href={u.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl text-sm font-medium transition-colors"
                  >
                    <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                    {u.title}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchTab;
