
import React, { useState, useRef } from 'react';
import { gemini, ImageInput } from '../services/geminiService';
import { GeneratedImage } from '../types';

const VisionTab: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<ImageInput | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setSelectedImage({
          data: base64String,
          mimeType: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const clearSelectedImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleGenerate = async () => {
    if ((!prompt.trim() && !selectedImage) || loading) return;
    setLoading(true);
    try {
      const result = await gemini.generateImage(prompt || "Analyze and refine this image", selectedImage || undefined);
      
      if (result.imageUrl) {
        const newImg: GeneratedImage = {
          id: Date.now().toString(),
          url: result.imageUrl,
          prompt: prompt || (selectedImage ? "Image Transformation" : "Generated"),
          timestamp: Date.now()
        };
        setImages(prev => [newImg, ...prev]);
        setPrompt('');
        clearSelectedImage();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-12">
      <div className="flex flex-col items-center gap-8 bg-black text-white p-12 rounded-[40px] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none">
          <div className="absolute top-[-50%] left-[-20%] w-[100%] h-[200%] bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 blur-3xl animate-pulse"></div>
        </div>
        
        <div className="z-10 text-center space-y-4">
          <h2 className="text-4xl font-bold">Vision Lab</h2>
          <p className="text-gray-400">Generate from scratch or transform your own photos with AI.</p>
        </div>

        <div className="z-10 w-full max-w-2xl space-y-4">
          {selectedImage && (
            <div className="relative inline-block group">
              <img 
                src={`data:${selectedImage.mimeType};base64,${selectedImage.data}`} 
                className="w-24 h-24 object-cover rounded-2xl border-2 border-white/20 shadow-xl"
                alt="Upload preview"
              />
              <button 
                onClick={clearSelectedImage}
                className="absolute -top-2 -right-2 bg-white text-black rounded-full p-1 shadow-lg hover:bg-gray-200 transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          )}

          <div className="flex gap-3 p-2 bg-white/10 backdrop-blur-md rounded-3xl border border-white/20">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-4 text-white hover:bg-white/10 rounded-2xl transition-colors"
              title="Upload reference image"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              accept="image/*" 
              className="hidden" 
            />
            
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
              placeholder={selectedImage ? "What should I do with this image?" : "A surreal floating city above a neon ocean..."}
              className="flex-1 bg-transparent border-none text-white px-4 py-4 focus:ring-0 outline-none placeholder:text-gray-500"
            />
            <button
              onClick={handleGenerate}
              disabled={(!prompt.trim() && !selectedImage) || loading}
              className="bg-white text-black font-bold px-8 rounded-2xl hover:bg-gray-200 transition-colors disabled:opacity-50"
            >
              {loading ? 'Processing...' : selectedImage ? 'Transform' : 'Create'}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {loading && (
          <div className="aspect-square bg-gray-50 rounded-[32px] animate-pulse flex items-center justify-center border-2 border-dashed border-gray-200">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-gray-200 border-t-black rounded-full animate-spin mx-auto mb-4"></div>
              <span className="text-gray-400 font-medium">Synthesizing Vision...</span>
            </div>
          </div>
        )}
        {images.map((img) => (
          <div key={img.id} className="group relative aspect-square bg-white rounded-[32px] overflow-hidden apple-shadow transition-transform hover:scale-[1.02]">
            <img src={img.url} alt={img.prompt} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity p-8 flex flex-col justify-end">
              <p className="text-white text-sm font-medium leading-relaxed line-clamp-3">{img.prompt}</p>
              <button 
                onClick={() => window.open(img.url, '_blank')}
                className="mt-4 w-full py-3 bg-white text-black rounded-xl text-sm font-bold"
              >
                Download
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VisionTab;
