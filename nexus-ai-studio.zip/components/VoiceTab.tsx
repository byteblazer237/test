
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

const VoiceTab: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcript, setTranscript] = useState<string[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Manual implementation of base64 decoding as required by Gemini API guidelines
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  // Manual implementation of base64 encoding as required by Gemini API guidelines
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  // Custom audio decoding function for raw PCM data streams returned by the Gemini Live API
  async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  const toggleSession = async () => {
    if (isActive) {
      sessionRef.current?.close();
      setIsActive(false);
      return;
    }

    setIsConnecting(true);
    // Fix: Always create a new GoogleGenAI instance right before making an API call
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            setIsConnecting(false);
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const processor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
              
              // Use the manual encode function to safely convert PCM bytes to base64
              const base64Data = encode(new Uint8Array(int16.buffer));
              
              // Always send realtime input using the resolved session promise to avoid stale closures
              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  media: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
                });
              });
            };
            
            source.connect(processor);
            processor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (msg.serverContent?.outputTranscription) {
              setTranscript(prev => [...prev.slice(-5), `Nexus: ${msg.serverContent!.outputTranscription!.text}`]);
            }
            if (msg.serverContent?.inputTranscription) {
               setTranscript(prev => [...prev.slice(-5), `You: ${msg.serverContent!.inputTranscription!.text}`]);
            }

            const audioData = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              const ctx = outputAudioContextRef.current!;
              // Track end time of the previous chunk for seamless playback
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (msg.serverContent?.interrupted) {
              // Handle model interruption by stopping all currently playing sources
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error('Session error', e);
            setIsConnecting(false);
            setIsActive(false);
          },
          onclose: () => {
            setIsActive(false);
            setIsConnecting(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: "You are Nexus, a real-time conversational companion. Be concise and natural.",
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        }
      });
      
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsConnecting(false);
    }
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-6 space-y-12">
      <div className="relative flex items-center justify-center">
        {isActive && (
          <div className="absolute w-[400px] h-[400px] rounded-full border border-black/5 animate-ping"></div>
        )}
        <div className={`w-64 h-64 rounded-full flex items-center justify-center transition-all duration-500 apple-shadow ${
          isActive ? 'bg-black text-white scale-110' : 'bg-white text-black'
        }`}>
          <button 
            onClick={toggleSession}
            disabled={isConnecting}
            className="w-full h-full flex flex-col items-center justify-center gap-4"
          >
            {isConnecting ? (
               <div className="w-10 h-10 border-4 border-gray-200 border-t-black rounded-full animate-spin"></div>
            ) : (
              <svg className={`w-20 h-20 ${isActive ? 'animate-pulse' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            )}
            <span className="font-bold tracking-widest uppercase text-xs">
              {isActive ? 'Live' : isConnecting ? 'Initializing' : 'Start Session'}
            </span>
          </button>
        </div>
      </div>

      <div className="w-full max-w-xl bg-white border border-gray-100 rounded-[32px] p-8 apple-shadow">
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Real-time Stream</h3>
        <div className="space-y-4 h-48 overflow-y-auto pr-4 scroll-smooth">
          {transcript.length === 0 ? (
            <p className="text-gray-400 italic text-sm">Waiting for conversation to start...</p>
          ) : (
            transcript.map((line, i) => (
              <div key={i} className={`text-sm ${line.startsWith('Nexus:') ? 'text-black font-semibold' : 'text-gray-500'}`}>
                {line}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default VoiceTab;
