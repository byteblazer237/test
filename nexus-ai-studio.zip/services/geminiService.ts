
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";

export interface ImageInput {
  data: string;
  mimeType: string;
}

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Fix: Initialize GoogleGenAI with a named parameter as per guidelines
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async generateChatResponse(prompt: string, history: { role: string, parts: { text: string }[] }[]) {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: "You are Nexus, a helpful and sophisticated AI assistant with a clean, professional, yet friendly personality. Use markdown for formatting.",
      }
    });
    return response.text;
  }

  async searchGrounding(query: string) {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    
    // Fix: Correctly extract grounding metadata URLs as per guidelines
    const urls = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      uri: chunk.web?.uri,
      title: chunk.web?.title
    })).filter((c: any) => c.uri) || [];

    return {
      text: response.text,
      urls
    };
  }

  async generateImage(prompt: string, imageInput?: ImageInput) {
    const parts: any[] = [{ text: prompt }];
    
    if (imageInput) {
      parts.unshift({
        inlineData: {
          data: imageInput.data,
          mimeType: imageInput.mimeType
        }
      });
    }

    const response = await this.ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: parts,
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    let imageUrl = '';
    let textResponse = '';
    
    // Fix: Iterate over all parts to correctly find image and text data from nano banana models
    for (const part of response.candidates?.[0]?.content.parts || []) {
      if (part.inlineData) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
      } else if (part.text) {
        textResponse = part.text;
      }
    }
    
    return { imageUrl, textResponse };
  }
}

export const gemini = new GeminiService();
